#include <stdio.h>

int main()
{
int myvariable;
	scanf("%d", &myvariable);
  	return 0;
}

